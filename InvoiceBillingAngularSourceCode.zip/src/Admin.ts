export class Admin {
    
    adminId!:number;
    dminLoginId!: string;
    adminName!: string;
    adminPassword!: string;
   

}
