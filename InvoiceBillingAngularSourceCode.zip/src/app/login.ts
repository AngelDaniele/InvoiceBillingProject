export class Login{
    constructor(
     
      public adminLoginId:string,
      public adminPassword:string
      
    ) {}
  }

 