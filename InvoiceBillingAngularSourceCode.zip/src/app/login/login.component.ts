import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { Admin } from 'src/Admin';
import { LoginService } from './login.service';
import { Router } from '@angular/router';
import { Employee } from '../admin/Employee';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login: Login=new Login("","");
  verify:Admin = new Admin();
  loginFailed = false;
  
  constructor(private loginService:LoginService,private route:Router,private router: Router) { }
  ngOnInit(): void {
  }

  adminLogin() {
    console.log("Admin Login component");
    
    this.loginService.LoginService(this.login).subscribe(
      data => {
        console.log(data);
        
        this.route.navigate(['/admin']);
        
      },
      error => {
        console.error(error);
        this.loginFailed = true;
       
      }
    );
  }



  




}














