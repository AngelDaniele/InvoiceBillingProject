import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Login } from '../login';
import { Admin } from 'src/Admin';

@Injectable({
    providedIn: 'root'
  })

  export class LoginService {

    constructor(private http:HttpClient) { }
    
    public LoginService(login:Login): Observable<Admin>{
        return this.http.post<Admin>("http://localhost:8080/Admin/login",login);
      }
   
      getAllEmployee(): Observable<any> {
        return this.http.get("http://localhost:8080/Employee/allEmployee");
      }

      getAllTimeSheetEntries(): Observable<any> {
        return this.http.get("http://localhost:8080/timesheet/entries");
      }


    }