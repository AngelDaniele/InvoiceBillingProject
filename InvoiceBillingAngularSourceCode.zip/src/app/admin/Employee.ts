export class Employee {
    billingRate: any;
  billingHours: any;
    constructor(
      public employeeLoginId?: number,
      public employeeName: string = '',
      public designation: string = ''
    ) {}
  }
  