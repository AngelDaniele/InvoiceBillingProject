
import { Employee } from "./Employee";
import { Project } from "./project";


export class TimeSheetEntry {
    timeSheetEntryId: number;
    employee: Employee;
    project: Project;
    date: Date;
    workingHours: number;
  
    constructor(
      timeSheetEntryId: number,
      employee: Employee,
      project: Project,
      date: Date,
      workingHours: number
    ) {
      this.timeSheetEntryId = timeSheetEntryId;
      this.employee = employee;
      this.project = project;
      this.date = date;
      this.workingHours = workingHours;
    }
  }
