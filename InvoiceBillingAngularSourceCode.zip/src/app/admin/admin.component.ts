import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login/login.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

 
  employees: any;
  taxPercentage: number = 0; 
  grandTotal: number = 0; 
  timeSheetEntries: any; 
  startDate: string = ''; 
  endDate: string = '';

  constructor(private loginService:LoginService,private route:Router) { }
  ngOnInit(): void {

    this.getAllEmployee();
  }


  getAllEmployee() {
   
    this.loginService.getAllEmployee().subscribe((employees: any) => this.employees = employees);
    

  }
  
  
  calculateSubtotal(): number {
    if (this.employees) {
      const subtotal = this.employees.reduce((total: number, employee: any) => {
        const totalPerEmployee = employee.billingHours * employee.billingRate;
        return total + totalPerEmployee;
      }, 0);

      const taxAmount = (this.taxPercentage / 100) * subtotal;

      this.grandTotal = subtotal + taxAmount;

      return subtotal;
    }
    return 0; 
  }

  calculateGrandTotal(): number {
    const subtotal = this.calculateSubtotal();
    const taxAmount = (subtotal * this.taxPercentage) / 100;
    return subtotal + taxAmount;
  }
  
  printPage(){

    window.print();

    
    

}


getAllTimeSheetEntries() {
  this.loginService.getAllTimeSheetEntries().subscribe(
    (entries: any) => {
      this.timeSheetEntries = entries;
      
    },
    (error: any) => {
      console.error('Error fetching time sheet entries:', error);
      
    }
  );
}

openComposeEmail(): void {
  const recipient = 'recipient@example.com';
  const subject = 'Your Subject';
  const body = 'Your email message here';

  
  const encodedSubject = encodeURIComponent(subject);
  const encodedBody = encodeURIComponent(body);

  const mailtoLink = `mailto:${recipient}?subject=${encodedSubject}&body=${encodedBody}`;

  window.location.href = mailtoLink;
}
}





 




  
 








