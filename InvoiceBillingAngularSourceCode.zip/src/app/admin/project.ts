export class Project {
    projectId: number;
    projectName: string;
    clientCompanyName: string;
    budget: number;
    startDate: Date;
    endDate: Date;
  
    constructor(
      projectId: number,
      projectName: string,
      clientCompanyName: string,
      budget: number,
      startDate: Date,
      endDate: Date
    ) {
      this.projectId = projectId;
      this.projectName = projectName;
      this.clientCompanyName = clientCompanyName;
      this.budget = budget;
      this.startDate = startDate;
      this.endDate = endDate;
    }
  }
  




