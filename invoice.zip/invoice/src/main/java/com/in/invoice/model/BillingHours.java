package com.in.invoice.model;

import javax.persistence.*;
import java.time.LocalTime;

@Entity
public class BillingHours {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
        private int BillingHoursId;



    @ManyToOne
    @JoinColumn(name = "employeeLoginId")
    private Employee employee;

    private LocalTime billingHours;


    public LocalTime getBillingHours() {
        return billingHours;
    }

    public void setBillingHours(LocalTime billingHours) {
        this.billingHours = billingHours;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }



    public int getBillingHoursId() {
        return BillingHoursId;
    }

    public void setBillingHoursId(int billingHoursId) {
        BillingHoursId = billingHoursId;
    }



    }


