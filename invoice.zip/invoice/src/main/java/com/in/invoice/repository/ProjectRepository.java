package com.in.invoice.repository;

import com.in.invoice.model.Employee;
import com.in.invoice.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProjectRepository extends JpaRepository<Project,Integer> {
}
