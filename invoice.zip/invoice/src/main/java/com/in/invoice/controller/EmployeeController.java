package com.in.invoice.controller;

import com.in.invoice.model.Employee;
import com.in.invoice.service.AdminService;
import com.in.invoice.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/Employee")
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;


    @GetMapping("/allEmployee")
    public List<Employee> getAllEmployee(){

        return employeeService.getAllEmployee();
    }


}
