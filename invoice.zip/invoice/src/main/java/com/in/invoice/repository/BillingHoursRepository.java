package com.in.invoice.repository;

import com.in.invoice.model.BillingHours;
import org.springframework.data.jpa.repository.JpaRepository;


public interface BillingHoursRepository extends JpaRepository<BillingHours, Integer> {
    // You can add custom query methods if needed{






}
