package com.in.invoice.service;

import com.in.invoice.model.TimeSheetEntry;
import com.in.invoice.repository.TimeSheetEntryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class TimeSheetEntryService


{
    @Autowired
    TimeSheetEntryRepository timeSheetEntryRepository;



    public List<TimeSheetEntry> getAllTimeSheetEntries() {
        return timeSheetEntryRepository.findAll();
    }





















}
