package com.in.invoice.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int employeeLoginId;
    private String employeeName;
    private String designation;


    public int getEmployeeLoginId() {
        return employeeLoginId;
    }

    public void setEmployeeLoginId(int employeeLoginId) {
        this.employeeLoginId = employeeLoginId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }


}






