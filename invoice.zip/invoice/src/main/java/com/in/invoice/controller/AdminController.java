package com.in.invoice.controller;

import com.in.invoice.exception.InvalidCredentialsException;
import com.in.invoice.model.Admin;
import com.in.invoice.model.AdminLoginDTO;
import com.in.invoice.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/Admin")
public class AdminController {

    @Autowired
    AdminService adminService;


    @PostMapping("/saveAdmin")
    public ResponseEntity<Admin> saveAdmin(@RequestBody Admin admin) {
        Admin responseAdmin = adminService.saveAdmin(admin);
        return new ResponseEntity<Admin>(responseAdmin, HttpStatus.CREATED);
    }


    @PostMapping("/login")
    public ResponseEntity<Admin> loginAdmin(@RequestBody AdminLoginDTO loginDTO) {
        {
            Admin msg= adminService.loginAdmin(loginDTO);
            return new ResponseEntity<Admin>(msg,HttpStatus.ACCEPTED);
        }







}}
