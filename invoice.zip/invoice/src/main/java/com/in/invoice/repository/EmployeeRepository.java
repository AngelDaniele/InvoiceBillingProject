package com.in.invoice.repository;

import com.in.invoice.model.Admin;
import com.in.invoice.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Integer> {


    public Employee findByEmployeeLoginId(Integer EmployeeLoginId);
}
