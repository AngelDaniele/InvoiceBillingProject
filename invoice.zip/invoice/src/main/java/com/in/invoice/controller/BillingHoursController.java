package com.in.invoice.controller;

import com.in.invoice.model.BillingHours;
import com.in.invoice.service.BillingHoursService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/billing-hours")
public class BillingHoursController {

    @Autowired
   BillingHoursService billingHoursService;




// ...






// ...

    @GetMapping("/{startDate}/{endDate}")
    public List<BillingHours> calculateBillingHours(
            @PathVariable("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @PathVariable("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return billingHoursService.calculateBillingHours(startDate, endDate);
    }











}
