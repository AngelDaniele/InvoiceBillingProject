package com.in.invoice.service;

import com.in.invoice.exception.InvalidCredentialsException;
import com.in.invoice.exception.UserAlreadyExists;
import com.in.invoice.model.Admin;
import com.in.invoice.model.AdminLoginDTO;
import com.in.invoice.repository.AdminRepository;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class AdminService {


    @Autowired
    private AdminRepository adminRepository;

    public Admin saveAdmin(Admin admin) {
        Admin admin1 = adminRepository.findByAdminLoginId(admin.getAdminLoginId());
        if (admin1 == null) {
            String password = admin.getAdminPassword();
            String hashedPassword = hashPassword(password);
            admin.setAdminPassword(hashedPassword);
            return adminRepository.save(admin);
        } else {
            throw new UserAlreadyExists("User Already Exists");
        }
    }

    private String hashPassword(String password) {
        // Use SHA-256 algorithm to hash the password
        String hashedPassword = DigestUtils.sha256Hex(password);

        return hashedPassword;
    }

    public Admin loginAdmin(AdminLoginDTO loginDTO) {
        Admin admin = adminRepository.findByAdminLoginId(loginDTO.getAdminLoginId());
        if (admin != null) {
            String storedHashedPassword = admin.getAdminPassword();
            String providedPassword = loginDTO.getAdminPassword();

            if (isPasswordMatch(providedPassword, storedHashedPassword)) {
                return admin;
            }
        }
        throw new InvalidCredentialsException("Invalid credentials");
    }

    private boolean isPasswordMatch(String providedPassword, String storedHashedPassword) {
        String hashedProvidedPassword = hashPassword(providedPassword);
        return hashedProvidedPassword.equals(storedHashedPassword);
    }

        }
