package com.in.invoice.service;

import com.in.invoice.exception.EmployeeNotFoundException;
import com.in.invoice.model.Employee;
import com.in.invoice.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;



    public List<Employee> getAllEmployee() {

        List<Employee> list = employeeRepository.findAll();

        if (list.size() > 0) {
            return list;
        } else
            throw new EmployeeNotFoundException("No Employee");
    }




}
