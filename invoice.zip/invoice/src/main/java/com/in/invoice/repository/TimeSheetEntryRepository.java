package com.in.invoice.repository;

import com.in.invoice.model.Project;
import com.in.invoice.model.TimeSheetEntry;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface TimeSheetEntryRepository extends JpaRepository<TimeSheetEntry,Integer> {
    List<TimeSheetEntry> findByDateBetween(LocalDate startDate, LocalDate endDate);
}
