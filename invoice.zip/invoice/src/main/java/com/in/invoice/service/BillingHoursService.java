package com.in.invoice.service;

import com.in.invoice.model.BillingHours;
import com.in.invoice.model.Employee;
import com.in.invoice.model.TimeSheetEntry;
import com.in.invoice.repository.BillingHoursRepository;
import com.in.invoice.repository.EmployeeRepository;
import com.in.invoice.repository.TimeSheetEntryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class BillingHoursService {
    @Autowired
    TimeSheetEntryRepository timeSheetEntryRepository;


    @Autowired
    EmployeeRepository employeeRepository;





    @Autowired
    BillingHoursRepository billingHoursRepository;



    public List<BillingHours> calculateBillingHours(LocalDate startDate, LocalDate endDate) {
        List<BillingHours> billingHoursList = new ArrayList<>();

        // Fetch TimeSheetEntries for the date range
        List<TimeSheetEntry> timeSheetEntries = timeSheetEntryRepository.findByDateBetween(startDate, endDate);

        // Calculate billing hours for each employee
        Map<Integer, Double> totalHoursByEmployeeId = new HashMap<>();

        for (TimeSheetEntry timeSheetEntry : timeSheetEntries) {
            int employeeId = timeSheetEntry.getEmployee().getEmployeeLoginId();
            double totalHours = totalHoursByEmployeeId.getOrDefault(employeeId, 0.0);
            totalHours += calculateTotalHours(timeSheetEntry, startDate, endDate);
            totalHoursByEmployeeId.put(employeeId, totalHours);
        }

        // Create BillingHours objects
        for (Map.Entry<Integer, Double> entry : totalHoursByEmployeeId.entrySet()) {
            BillingHours billingHours = new BillingHours();

            // Retrieve the Employee from the repository with proper values
            Employee employee = employeeRepository.findByEmployeeLoginId(entry.getKey());

            // Set the employee using setEmployee method
            billingHours.setEmployee(employee);

            double totalBillingHours = entry.getValue();
            long totalSeconds = (long) (totalBillingHours * 3600); // Convert hours to seconds

            int hours = (int) (totalSeconds / 3600); // Get the number of hours
            int minutes = (int) ((totalSeconds % 3600) / 60); // Get the remaining minutes

            LocalTime billingTime = LocalTime.of(hours, minutes);
            billingHours.setBillingHours(billingTime);
            billingHoursRepository.save(billingHours);

            billingHoursList.add(billingHours);
        }

        return billingHoursList;
    }

    private double calculateTotalHours(TimeSheetEntry timeSheetEntry, LocalDate startDate, LocalDate endDate) {
        // Initialize total working hours to 0.0
        double totalHours = 0.0;

        // Get the date from the TimeSheetEntry
        LocalDate entryDate = timeSheetEntry.getDate();

        // Check if the entryDate falls within the specified date range
        if (entryDate.isEqual(startDate) || (entryDate.isAfter(startDate) && entryDate.isBefore(endDate.plusDays(1)))) {
            // If the entryDate is within the range, add the working hours to the total
            totalHours += timeSheetEntry.getWorkingHours().getHour(); // Assuming workingHours is in hours
        }

        return totalHours;
    }


}










