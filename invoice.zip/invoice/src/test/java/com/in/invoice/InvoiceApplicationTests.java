package com.in.invoice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvoiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
